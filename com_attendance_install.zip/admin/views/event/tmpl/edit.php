<?php
// No direct access
defined ( '_JEXEC' ) or die ( 'Restricted access' );
JHtml::_ ( 'behavior.tooltip' );
?>
<form
	action="<?php echo JRoute::_('index.php?option=com_attendance&view=event&layout=edit&id='. $this->item->id); ?>"
	method="post" name="adminForm" id="adminForm">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_ATTENDANCE_EVENT_DETAILS' ); ?></legend>
		<ul class="adminformlist">
			<?php foreach($this->form->getFieldset() as $field): ?>			<li><?php echo $field->label;echo $field->input;?></li>			<?php endforeach; ?> 		</ul>
	</fieldset>
			<?php if ($this->grouplist) :?>
		<fieldset id="user-groups" class="adminform">
			<legend><?php echo JText::_('COM_ATTENDANCE_EVENT_ASSIGNED_GROUPS'); ?></legend>
			<?php echo $this->loadTemplate('groups');?>
		</fieldset>
		<?php endif; ?>
	<div>
		<input type="hidden" name="task" value="" /><?php echo JHtml::_('form.token'); ?>	</div>
</form>
