<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<tr> 
        <th>
                <?php echo JText::_('Name'); ?>
        </th>
        <th>
                <?php echo JText::_('Date/Time'); ?>
        </th>                
        <th>
                <?php echo JText::_('Location'); ?>
        </th>
        <th>
                <?php echo JText::_('Yes'); ?>
        </th>
        <th>
                <?php echo JText::_('No'); ?>
        </th>
        <th>
                <?php echo JText::_('Reason'); ?>
        </th>
        <th>
                <?php echo JText::_('Response Details');?>
        </th>
                <th>
                <?php echo JText::_('Edit');?>
        </th>
                
</tr>