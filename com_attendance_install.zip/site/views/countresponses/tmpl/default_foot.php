<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
